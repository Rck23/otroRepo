from setuptools import setup, find_packages

setup(
    name="otroRepo",
    version="0.1.1", 
    packages=find_packages(),
    description="Un paquete pip simple de saludo",
    author="Ulises",
    author_email="U@gmail.com",
    url="https://github.com/Rck23/otroRepo"
)