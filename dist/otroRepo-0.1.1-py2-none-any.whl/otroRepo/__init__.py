def saludar(nombre):
    return "Hola" + nombre + ", primer paquete"